<!DOCTYPE html>
<html>
<head>
	@include('includes.head')
</head>
<body style="padding-top: 61.7px;">
	@include('includes.navbar')
	@yield('content')
</body>
</html>