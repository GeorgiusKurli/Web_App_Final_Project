<!DOCTYPE html>
<html>
<head>
	@include('includes.head')
</head>
<body style="padding-top: 62px;">
	@include('includes.navbar')
	@yield('content')
</body>
</html>