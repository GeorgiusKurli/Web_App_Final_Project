<!-- Footer -->
<footer class="page-footer font-small teal pt-4" style="background-color: #1475CF">

    <!-- Footer Links -->
    <div class="container">

      <!-- Grid row-->
      <div class="row text-center d-flex justify-content-center pt-5 mb-3">

        <!-- Grid column -->
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="#!" style="color: black; font-weight: bold">Home</a>
          </h6>
        </div>


        <!-- Grid column -->
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="#!" style="color: black; font-weight: bold">About us</a>
          </h6>
        </div>

        <!-- Grid column -->
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="#!" style="color: black; font-weight: bold">Contact</a>
          </h6>
        </div>


      </div>
      <!-- Grid row-->
      <hr class="rgba-white-light" style="margin: 0 15%;">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-5"><i>Copyright © 2019 
      <a style="font-weight: bold;">Exams Online</a>, All rights reserved.</i>
    </div>
    <!-- Copyright -->
  </div>
  </footer>
  <!-- Footer -->