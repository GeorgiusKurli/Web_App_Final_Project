@extends('layouts.master')

@section('content')
	<script type="text/javascript">
		document.getElementById('nav_home').className= "nav-item active";
	</script>
	<h3 style="text-align: center;">Ready to take your exams?</h3>
	<img style="display:block; margin-left: auto; margin-right: auto; width: 50%; height: 50%;" src="https://media1.giphy.com/media/12vJgj7zMN3jPy/giphy.gif?cid=3640f6095c9373d368563067737c3697">
	
@stop