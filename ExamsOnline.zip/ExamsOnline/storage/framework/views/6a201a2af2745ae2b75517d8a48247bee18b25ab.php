<?php $__env->startSection('content'); ?>
<?php
	use Illuminate\Support\Facades\DB;
	use App\Question;
	use App\Choice;
?>
<h1 class="question my-5" style="text-align: center; color: #1475CF";><?php echo e($test->test_name); ?></h1>
	<form action="<?php echo e(url('testresult')); ?>">
		<input type="hidden" name="test_id" value="<?php echo e($test->id); ?>">

		<!-- create all questions -->
		<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<input type="hidden" name="question_number" value="<?php echo e($loop->count); ?>">

		<input type="hidden" name="question_id<?php echo e($loop->index); ?>" value="<?php echo e($question->id); ?>">

		<div class="col-md-6 mx-auto my-5" style="background-color: rgb(200,200,200);">
			<h3><?php echo e($question->question); ?></h3>
		</div>
		<?php 
			$choices = DB::table('choices')->where('question_id', '=', $question->id)->get();
		?>
		<div>
			<!-- get index number -->
			<?php 
				$curr_itr = $loop->index;
			?>

			<!-- create all choices -->
			<?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="form-check col-md-6 mx-auto my-5" >
				<input class="form-check-input" type="radio" name="choice<?php echo e($curr_itr); ?>" value="<?php echo e($choice->choice); ?>">
				<label class="form-check-label" for="Radio1"><?php echo e($choice->choice); ?></label>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<button type="submit" class="btn btn-primary col-md-1 offset-md-5 mb-5">Check</button>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\XAMPP\htdocs\ExamsOnline\resources\views/showquestion.blade.php */ ?>