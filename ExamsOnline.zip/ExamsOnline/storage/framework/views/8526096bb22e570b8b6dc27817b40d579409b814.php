<?php $__env->startSection('content'); ?>
	<script type="text/javascript">
		document.getElementById('nav_create').className= "nav-item active";
	</script>
	<form method="post" action="<?php echo e(route('tests.store')); ?>" class="col-md-8 mx-auto mt-4">
		<div class="form-group">
			<?php echo csrf_field(); ?>
			<label for="test_name">Test Name:</label>
			<input type="text" class="form-control mb-3" name="test_name" placeholder="Your Test Name" required>
			<label for="category">Category:</label>
			<input type="text" class="form-control" name="category" placeholder="Test Category" required>
			<input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
		</div>

		<button type="submit" class="btn btn-primary col-md-2 offset-md-5">Create Test</button>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\XAMPP\htdocs\ExamsOnline\resources\views/createtest.blade.php */ ?>