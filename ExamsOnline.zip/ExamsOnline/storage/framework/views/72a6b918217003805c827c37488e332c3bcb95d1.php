<?php $__env->startSection('content'); ?>
	<script type="text/javascript">
		document.getElementById('nav_create').className= "nav-item active";
	</script>
	<?php if(session()->get('success')): ?>
		<script type="text/javascript">
			bootstrap_alert("<?php echo e(session()->get('success')); ?>", 'success')
		</script>
	<?php endif; ?>
	<h5 class="my-3" style="text-align: center;">Test Editing Area</h5>
	<div>
		<form action="<?php echo e(route('questions.create')); ?>">
			
			<button class="btn btn-primary col-md-2 offset-md-5 my-4">Create A Question</button>
		</form>
		<table class="col-md-10 offset-md-1">
			<thead>
				<tr style="border-bottom: solid;">
					<td><b>No.</b></td>
					<td><b>Question</b></td>
					<td><b>Action</b></td>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr style="border-bottom: solid;">
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($question->question); ?></td>
					<!-- <td><a href="<?php echo e(route('questions.edit',$question->id)); ?>" class="btn btn-primary">Edit</a></td> -->
					<td>
					<form action="<?php echo e(route('questions.destroy', $question->id)); ?>" method="post">
						<?php echo csrf_field(); ?>
						<?php echo method_field('DELETE'); ?>
						<button class="btn btn-danger" type="submit">Delete</button>
					</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\XAMPP\htdocs\ExamsOnline\resources\views/edit.blade.php */ ?>