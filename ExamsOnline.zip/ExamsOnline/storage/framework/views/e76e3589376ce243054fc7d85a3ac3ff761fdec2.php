<head>
	<title>Exams Online</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel='icon' href="<?php echo e(asset('EO.ico')); ?>" type='image/x-icon'/>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
	<script src="<?php echo e(asset('js/myjs.js')); ?>"></script>
</head>
<?php /* D:\XAMPP\htdocs\ExamsOnline\resources\views/includes/head.blade.php */ ?>