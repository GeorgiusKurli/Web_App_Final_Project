<?php echo e($slot); ?>


<?php /* D:\XAMPP\htdocs\ExamsOnline\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>