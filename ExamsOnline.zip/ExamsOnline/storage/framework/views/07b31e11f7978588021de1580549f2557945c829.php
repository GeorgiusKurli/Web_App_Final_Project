<!DOCTYPE html>
<html>
<head>
	<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="padding-top: 62px;">
	<?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /* D:\XAMPP\htdocs\ExamsOnline\resources\views/layouts/master.blade.php */ ?>