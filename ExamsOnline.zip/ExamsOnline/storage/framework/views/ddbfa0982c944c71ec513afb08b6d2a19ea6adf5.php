<?php $__env->startSection('content'); ?>
	<script type="text/javascript">
		document.getElementById('nav_browse').className= "nav-item active";
	</script>

	<form class="col-md-8 offset-md-2 mt-2" action="<?php echo e(url('browse')); ?>">
		<div class="form-group row">
			<?php echo csrf_field(); ?>
			<input class="form-control ml-auto col-sm-6 col-md-4" type="search" placeholder="Search" name="search">
			<button type="submit" class="btn btn-primary mr-auto"> Submit </button>
		</div>
		<div class="form-group row">
			<div class="dropdown col-md-2 offset-md-7">
				<button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown">Advanced</button>
				<div class="dropdown-menu">
					<div class="dropdown-item">
						<label class="form-check-label" for="search_id">ID</label>
						<input class="form-control" type="search" name="id" id="search_id">
					</div>
					<div class="dropdown-item">
						<label class="form-check-label" for="search_category">Category</label>
						<input class="form-control" type="search" name="category" id="search_category">
					</div>
					
				</div>
			</div>
		</div>
	</form>
	<div>
		<table class="col-md-8 offset-md-2">
			<thead>
				<tr>
					<td><b>ID</b></td>
					<td><b>Test Name</b></td>
					<td><b>Category</b></td>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($test->id); ?></td>
					<td><a href="<?php echo e(url('showquestion/' . $test->id)); ?>"><?php echo e($test->test_name); ?></a></td>
					<td><?php echo e($test->category); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
	<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\XAMPP\htdocs\ExamsOnline\resources\views/browse.blade.php */ ?>